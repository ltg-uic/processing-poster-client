package tmp;

import processing.core.PImage;
import vialab.SMT.ImageZone;

/**
 * Created by aperritano on 8/11/14.
 */
public class NewTextButton extends ImageZone {


    public NewTextButton(String name, PImage image, int x, int y, int width, int height) {
        super(name, image, x, y, width, height);
    }
}
