package ltg.evl.uic.poster.listeners;

/**
 * Created by aperritano on 2/15/15.
 */
public interface SaveUserListerner {


    void saveUser(String userName);

}
