package ltg.evl.uic.poster.widgets;

public interface DeletableZone {

    void deleteThisZone();

}
