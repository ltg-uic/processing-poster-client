package ltg.evl.uic.poster.widgets;

import processing.core.PImage;
import vialab.SMT.ImageZone;

/**
 * Created by aperritano on 4/15/15.
 */
public class ScaleZone extends ImageZone {


    public ScaleZone(PImage pImage, int x, int y, int width, int height) {
        super(pImage, x, y, width, height);
    }

}
