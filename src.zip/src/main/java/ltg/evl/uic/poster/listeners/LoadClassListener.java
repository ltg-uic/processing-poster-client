package ltg.evl.uic.poster.listeners;

public interface LoadClassListener {
    void loadClass(String classname);
}
