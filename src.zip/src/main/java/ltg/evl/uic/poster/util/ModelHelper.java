package ltg.evl.uic.poster.util;

/**
 * Created by aperritano on 4/12/15.
 */
public class ModelHelper {

    public static long getTimestampMilli() {
        return System.currentTimeMillis();
    }
}
