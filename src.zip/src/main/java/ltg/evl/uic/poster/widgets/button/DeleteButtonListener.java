package ltg.evl.uic.poster.widgets.button;

import vialab.SMT.Zone;

public interface DeleteButtonListener {

    void deleteZone(Zone zone);
}
