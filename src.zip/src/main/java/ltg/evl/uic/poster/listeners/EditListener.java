package ltg.evl.uic.poster.listeners;

public interface EditListener {

    void editModeChanged(boolean isEditing);

}
