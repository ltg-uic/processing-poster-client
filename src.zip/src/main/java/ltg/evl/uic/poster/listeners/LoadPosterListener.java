package ltg.evl.uic.poster.listeners;

/**
 * Created by aperritano on 4/1/15.
 */
public interface LoadPosterListener {
    void loadPoster(String posterUuid);
}
