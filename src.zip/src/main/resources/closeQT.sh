osascript -e 'tell application "QuickTime Player" to close document 1'
